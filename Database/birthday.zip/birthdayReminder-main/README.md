# birthdayReminder
clone this repo
run npm install
run npm start 

