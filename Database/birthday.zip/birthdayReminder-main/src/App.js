import Birthdayreminder from './birthdayreminder'
function App() {
  return (
    <div>
      <Birthdayreminder/>
    </div>
  );
}

export default App;
