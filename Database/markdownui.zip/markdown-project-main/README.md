# markdown-project
[markdown](https://festive-lovelace-0b2ad9.netlify.app/)
all dependency
> npm install react-markdown
```
react hooks comes with react
```

## clone this repo

##  run npm install

## run npm start 
```
contribute to make it better
```
![Screenshot (138)](https://user-images.githubusercontent.com/77490569/127773466-ded557cd-701d-4087-b0ca-678f3f8f1dff.png)


