const people = [
  {
    id: 1,
    image:
      'https://th.bing.com/th/id/R.aa35a34bdbc74690f2a1eafbe2dcd7bd?rik=HvCYLlu%2fQJIK4Q&riu=http%3a%2f%2fclapway.com%2fwp-content%2fuploads%2f2015%2f11%2f13.-Hacker-1.jpg&ehk=hlegChp9QUJRHYdp6WJ9QbmqnVyd5NHbDty1owOU5b8%3d&risl=&pid=ImgRaw',
    name: 'mehruddin',
    title: 'Developer',
    quote:
      'hello  text  text text text text textt textt tetettxtetxtetxttxetetexxtett',
  },
  {
    id: 2,
    image:
      'https://th.bing.com/th/id/OIP.Mg1yAZqKQ_IAUrQwnUgeYQHaEK?pid=ImgDet&rs=1',
    name: 'Oggy',
    title: 'Cartton character',
    quote:
      'hello  text  text text text text textt textt tetettxtetxtetxttxetetexxtett.',
  },
  {
    id: 3,
    image:
      'https://th.bing.com/th/id/R.c6c6319c21bfc9de1bd43ae331c0a0d6?rik=Ln2Vm0ZcplzMzw&riu=http%3a%2f%2fimg08.deviantart.net%2fc0fe%2fi%2f2015%2f145%2f7%2f8%2fjack___vector__oggy_and_the_cockroaches__by_gt4tube-d8unylw.png&ehk=75vO4b46ci2wN18GSImdowK3%2fID2NKQGBNDZ94WZQDA%3d&risl=&pid=ImgRaw',
    name: 'Jack',
    title: 'Cartton character',
    quote:
      'hello  text  text text text text textt textt tetettxtetxtetxttxetetexxtett etxtxettxteteteetettexteteettexxetextextextextxettextextxetetxxetetextetettextextextextxexteetx.',
  },
  {
    id: 4,
    image:
      'http://vignette2.wikia.nocookie.net/oggyandthecockroaches/images/2/2b/207721_200016243365191_100000704505905_559531_6189265_n.jpg/revision/latest?cb=20121012132959',
    name: 'BOB',
    title: 'Cartton character',
    quote:
      'hello  text  text text text text textt textt tetettxtetxtetxttxetetexxtett etxtxettxteteteetettexteteettexxetextextextextxettextextxetetxxetetextetettextextextextxexteetx. ',
  },
];

export default people;
