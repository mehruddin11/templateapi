export const SET_LOADING = 'SET_LOADING';
export const SET_STORIES= 'SET_STORIES'; 
export const REMOVE_STORY = 'REMOVE_STORY';
export const SET_BUTTON = 'SET_BUTTON'
export const HANDLE_SEARCH='HANDLE_SEARCH'