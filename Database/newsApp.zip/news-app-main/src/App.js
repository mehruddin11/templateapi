import SearchForm from './searchform';
import Button from './button';
import Stories from './stories';
function App() {
  return (
    <div>
    <h4 className='intro'> Developer mehruddin </h4>
      <SearchForm/>
      <Button/>
      <Stories/>
    </div>
  );
}

export default App;
